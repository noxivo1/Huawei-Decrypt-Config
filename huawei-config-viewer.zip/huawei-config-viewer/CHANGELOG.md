# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

---

## [1.0.0] — 2026-03-03

### Added
- Initial release
- Full AES-128-CBC decryption of `$2...$` encrypted fields
- Support for `DBEncrypt="1"` backup files (`hw_ctree_*.html`)
- **WiFi section** — SSID, KeyPassphrase, PreSharedKey, WPS passwords (all decrypted on demand)
- **PPPoE section** — ISP username and decrypted password
- **Credentials section** — Web admin users, CLI/Telnet users, SSL cert passwords
- **LAN/DHCP section** — IP ranges, gateway, DNS, ACL settings
- **Connected Devices table** — Full MAC address history with timestamps and device types
- **WAN Connections** — All WAN interfaces with full details
- **TR-069/ACS section** — Remote management credentials (decrypted)
- **System Info** — Firmware version, ISP/operator, hardware stats
- **Raw XML viewer** — Original file content with download option
- Drag & drop file loading
- Click-to-reveal password fields
- One-click copy to clipboard
- 100% client-side, no backend required
- Password hash mode detection (AES-CBC / PBKDF2 / SHA256-MD5)
- Dark theme UI with Syne + JetBrains Mono fonts

### Security
- All processing is local — no data leaves the browser
- Clear warning labels distinguishing reversible (AES-CBC) vs irreversible (PBKDF2/SHA256) passwords

---

## [Unreleased]

### Planned
- [ ] Export decrypted config as JSON
- [ ] Edit fields and re-export as valid backup XML
- [ ] Support for `hw_ttree` binary format (with AES-ECB key derivation)
- [ ] QR code generation for WiFi credentials
- [ ] Port forwarding / NAT rules section
- [ ] Static DHCP leases section
- [ ] Dark/light theme toggle
