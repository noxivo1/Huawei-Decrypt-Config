# Huawei Config File Encryption — Technical Deep Dive

> Based on the original research by [André Brandão](https://blog.fayaru.me/posts/huawei_router_config/)

## Overview

Huawei routers with `DBEncrypt="1"` in their backup files encrypt sensitive configuration fields using **AES-128-CBC** with a proprietary encoding scheme. This document explains exactly how the encryption works and how this tool decrypts it.

---

## Identifying Encrypted Fields

Encrypted values always follow this pattern:

```
$2<encoded_payload>$
```

- Starts with `$2`
- Ends with `$`
- The `2` indicates the CBC variant (vs ECB which would be `$1`)

**Example:**
```xml
<WANPPPConnectionInstance Username="cnx-142310178"
  Password="$2)Uw|G$4~{S,]qGYo;/HNaNh;=C[/5CrE\=,1F.7$" />
```

---

## Decryption Algorithm

The decryption is implemented in `libhw_ssp_basic.so` on the router's firmware, in a function called `HW_OS_AESCBCDecrypt`. Here's how it works:

### Step 1 — Strip delimiters
Remove the `$2` prefix and `$` suffix.

### Step 2 — Decode with HW_AES_AscUnvisible
The encoded payload uses a custom encoding where each byte is represented as **two ASCII characters**, each offset by `0x23` (35):

```
byte = ((char[i] - 0x23) << 4) | (char[i+1] - 0x23)
```

This produces a raw binary buffer.

### Step 3 — Extract IV (HW_AES_PlainToBin)
Take the **last 20 bytes** of the decoded buffer and reduce them to 16 bytes via XOR folding:

```javascript
iv[0..15] = bytes[n-20..n-5]
iv[0]  ^= bytes[n-4]
iv[1]  ^= bytes[n-3]
iv[2]  ^= bytes[n-2]
iv[3]  ^= bytes[n-1]
```

### Step 4 — AES-128-CBC Decryption
- **Key:** `Df7!ui%s9(lmV1L8` (16 bytes, UTF-8)
- **IV:** derived in Step 3
- **Mode:** CBC
- **Padding:** PKCS7
- **Data:** all decoded bytes except the last 20

### Step 5 — Result
The decrypted bytes are the plaintext password/value, null-terminated.

---

## JavaScript Implementation

```javascript
const HW_KEY = "Df7!ui%s9(lmV1L8";

function hwAscUnvisible(str) {
  const bytes = [];
  for (let i = 0; i + 1 < str.length; i += 2) {
    const hi = str.charCodeAt(i) - 0x23;
    const lo = str.charCodeAt(i + 1) - 0x23;
    bytes.push((hi << 4) | lo);
  }
  return bytes;
}

function hwPlainToBin(bytes) {
  const out = new Uint8Array(16);
  for (let i = 0; i < 16; i++) out[i] = bytes[i];
  for (let i = 16; i < bytes.length; i++) out[i - 16] ^= bytes[i];
  return out;
}

function hwDecrypt(encStr) {
  const inner = encStr.slice(2, -1);               // strip $2 ... $
  const raw = hwAscUnvisible(inner);               // custom decode
  const ivBytes = hwPlainToBin(raw.slice(raw.length - 20)); // extract IV
  const iv  = CryptoJS.lib.WordArray.create(ivBytes);
  const key = CryptoJS.enc.Utf8.parse(HW_KEY);
  const data = CryptoJS.lib.WordArray.create(
    new Uint8Array(raw.slice(0, raw.length - 20))
  );
  const dec = CryptoJS.AES.decrypt(
    { ciphertext: data }, key,
    { iv, mode: CryptoJS.mode.CBC, padding: CryptoJS.pad.Pkcs7 }
  );
  return dec.toString(CryptoJS.enc.Utf8);
}
```

---

## Password Hash Modes

For user account passwords (web panel, CLI), Huawei uses hashing rather than encryption. These are **one-way** and cannot be reversed.

The mode is stored in the `PassMode` or `EncryptMode` attribute:

| Mode | Algorithm | Example field |
|---|---|---|
| `0` | Plaintext | Legacy devices |
| `1` | `MD5(password)` | Old firmware |
| `2` | `SHA256(MD5(password))` | Current standard |
| `3` | `PBKDF2(password, SHA256, 5000 iter, salt_24chars)` | Latest firmware |

The `Salt` attribute contains the base64-encoded salt for mode 3.

---

## Fields That Are Encrypted

Based on reverse engineering of `hw_aes_tree.xml` from Huawei firmware, the following fields use AES-CBC encryption (`$2...$`):

- `WANPPPConnectionInstance.Password`
- `WANIPConnectionInstance.X_HW_IPoEPassword`
- `PreSharedKeyInstance.KeyPassphrase`
- `PreSharedKeyInstance.PreSharedKey`
- `WPS.DevicePassword`
- `X_HW_WpsDefaultPinInstance.DevicePassword`
- `ManagementServer.Password`
- `ManagementServer.ConnectionRequestPassword`
- `ManagementServer.X_HW_CertPassword`
- `X_HW_WebSslInfo.CertPassword`
- `X_HW_RadiusKey`
- `SecondaryRadiusSecret`
- `X_HW_IPTV.Password`
- `OTTConfig.Password`
- `X_HW_CLOUDVR.Password`

---

## References

1. [Huawei configuration file password encryption](https://blog.fayaru.me/posts/huawei_router_config/) — André Brandão, 2021
2. [huawei-utility-page](https://github.com/andreluis034/huawei-utility-page) — Reference implementation
3. [AESCrypt2](https://github.com/palmerc/AESCrypt2) — File-level encryption tool
4. [Hacking Huawei HG8012H ONT](https://github.com/logon84/Hacking_Huawei_HG8012H_ONT) — Password mode research
