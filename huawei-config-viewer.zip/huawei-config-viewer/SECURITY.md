# Security Policy

## Supported Versions

| Version | Supported |
|---|---|
| 1.0.x | ✅ Active support |

## Scope

This project is a **client-side static HTML tool**. It has no server, no database, no backend, and no network requests beyond loading CryptoJS from a CDN.

All processing happens **exclusively in the user's browser**. No data is ever transmitted.

## Reporting a Vulnerability

If you discover a security vulnerability (e.g. XSS in the XML parser, logic errors in the decryption, etc.):

1. **Do NOT open a public issue**
2. Open a [private security advisory](../../security/advisories/new) on GitHub
3. Include:
   - Description of the vulnerability
   - Steps to reproduce
   - Potential impact
   - Suggested fix (if any)

You will receive a response within **72 hours**.

## Cryptographic Disclaimer

The AES-CBC key (`Df7!ui%s9(lmV1L8`) used in this tool is **not a secret** — it is hardcoded in Huawei's own firmware binary (`libhw_ssp_basic.so`) and was publicly documented by security researchers. This tool merely reimplements Huawei's own decryption logic in JavaScript.

Huawei router backup files (with `DBEncrypt="1"`) should **not** be treated as securely encrypted. Anyone with access to the file can decrypt it using this tool or the original firmware binary.

## Responsible Use

This tool is intended for legitimate use by:
- Device owners managing their own hardware
- Security researchers with authorization
- Network engineers performing authorized audits

Unauthorized access to network devices is illegal in most jurisdictions.
