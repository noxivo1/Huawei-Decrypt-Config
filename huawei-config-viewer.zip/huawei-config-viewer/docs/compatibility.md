# Device Compatibility

## How to Check Compatibility

Open your backup file in a text editor and check the first line:

```xml
<InternetGatewayDevice DBEncrypt="1">
```

If `DBEncrypt="1"` is present, this tool can decrypt the encrypted fields. If `DBEncrypt="0"` or the attribute is absent, passwords are stored in plaintext and the tool will still display them correctly.

---

## Confirmed Compatible Models

| Model | Series | Firmware | ISP | Tested |
|---|---|---|---|---|
| EchoLife HG8247H | ONT | V500R019C00 | Multiple | ✅ Full |
| EchoLife HG8247Q | ONT | V500R019C00 | Vodafone PT | ✅ Full |
| EchoLife HS8247W | ONT | V300R016C10 | Vodafone PT | ✅ Full |
| EchoLife HG8245H | ONT | V300R018C10 | Multiple | ✅ Full |
| EchoLife HG8145V | ONT | V300R016C10 | Multiple | ⚠️ Partial |
| EchoLife HG8010H | ONT | V300R016 | Multiple | ⚠️ Partial |
| EchoLife EG8145V5 | ONT | V500R021 | UNE (Colombia) | ✅ Full |

---

## Backup File Location

To obtain the backup file from your router:

1. Log in to the web interface (usually `192.168.1.1` or `192.168.100.1`)
2. Go to **System Tools** → **Configuration File** → **Backup**
3. The file is named `hw_ctree_<date>.html` or similar

> ⚠️ Some ISPs restrict access to the backup/restore page. In that case, a more advanced method (serial console, UART, flash dump) may be required.

---

## Known Limitations

- **Binary `hw_ttree` files** — These use a different encryption (AES-ECB with a key derived from the firmware binary). Not currently supported.
- **Very old firmware (< V200)** — May use plaintext storage without the `$2...$` format.
- **Custom ISP builds** — Some operators modify the firmware and may use different keys or encoding.

---

## Reporting Compatibility

If you test a model not listed above, please [open an issue](../../issues/new) with:
- Router model and hardware version
- Firmware version string (from System Info page or the backup file itself)
- Whether decryption worked correctly

Your contribution helps improve coverage for the community!
