---
name: 🐛 Bug Report
about: Report something that is not working correctly
title: '[BUG] '
labels: bug
assignees: ''
---

## 🐛 Bug Description

A clear and concise description of the bug.

## 📋 Steps to Reproduce

1. Open the tool at `...`
2. Load a file with `...`
3. Click on `...`
4. See error

## ✅ Expected Behavior

What you expected to happen.

## ❌ Actual Behavior

What actually happened. Include screenshots if helpful.

## 🔧 Environment

- **Browser:** (e.g. Chrome 121, Firefox 122, Safari 17)
- **OS:** (e.g. Windows 11, macOS 14, Ubuntu 22.04)
- **Router Model:** (e.g. Huawei HG8247H)
- **Firmware Version:** (e.g. V500R019C00SPC112)

## 📄 File Info

- Does your backup file start with `<InternetGatewayDevice DBEncrypt="1">`? (yes/no)
- Approximate file size:

## 📝 Additional Context

Any other context, console errors, or information that might help.
