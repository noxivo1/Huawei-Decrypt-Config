# Contributing to Huawei Config Viewer

Thank you for your interest in contributing! Here's how to get started.

## Development Setup

This project is a single HTML file — no build step required.

```bash
git clone https://github.com/yourusername/huawei-config-viewer.git
cd huawei-config-viewer
# Open index.html in your browser
```

For live-reload during development, you can use any simple HTTP server:

```bash
# Python
python3 -m http.server 8080

# Node.js
npx serve .
```

## What to Contribute

### High Priority
- [ ] Support for additional router models (test and report in issues)
- [ ] Export decrypted config to JSON
- [ ] Parse port forwarding / NAT rules
- [ ] Parse static DHCP reservations
- [ ] QR code generation for WiFi credentials

### Good First Issues
- Improve the UI for mobile screens
- Add more field descriptions/tooltips
- Better error messages when file parsing fails
- Add a search/filter function in the devices table

## Code Style

- Keep everything in a single `index.html` file (self-contained)
- Vanilla JavaScript only — no framework dependencies
- Comment non-obvious cryptographic steps
- All user-facing text in Spanish (primary audience) with English code comments

## Pull Request Process

1. Fork the repo and create a branch from `main`
2. Make your changes in `index.html` (and docs if relevant)
3. Test with at least one real backup file
4. Update `CHANGELOG.md` under `[Unreleased]`
5. Submit your PR with a clear description

## Security

If you find a security issue, please follow the [Security Policy](SECURITY.md) and **do not** open a public issue.
